const mongoose =require('mongoose')
const studentSchema= new mongoose.Schema({
    _id:{type:String,require:true},
    name:{type:String,require:true},
    date_of_birth:{type:Date},
    gender:{type:String},
    degreeId:{
        type:String,
        require:true,
        ref:'degree'
    },
    enroled_courses:[{type:mongoose.Schema.Types.ObjectId,ref:'courses'}]
})

const Student =mongoose.model('students',studentSchema)
const kolins =new Student({
    _id:'2020IT01',
    name:'Peter kolins',
    date_of_birth:'01-05-1995',
    gender:'male',
    degreeId:'FAS2000ICT',
    enroled_courses:['682aa19dd7e61d5e852f6fcc','682aa240e6cdd9858c7620f1']
})
//webservice.save()
module.exports=Student